//
//  ViewController.swift
//  ServerJson_01
//
//  Created by TJ on 2022/06/19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

